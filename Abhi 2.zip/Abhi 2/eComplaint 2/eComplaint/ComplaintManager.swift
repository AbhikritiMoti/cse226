//
//  ComplaintManager.swift
//  eComplaint
//
//  Created by Student on 30/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import Foundation
class ComplaintManager {
    static let shared = ComplaintManager()
    

}
