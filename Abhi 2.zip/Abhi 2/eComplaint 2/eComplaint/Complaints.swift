//
//  Complaints.swift
//  eComplaint
//
//  Created by Student on 30/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import Foundation
struct Complaints {
    var name: String
    var id: String
    var address: String
    var age: Int
    var priority: String
    var query: String
    var isQuick: Bool
}
