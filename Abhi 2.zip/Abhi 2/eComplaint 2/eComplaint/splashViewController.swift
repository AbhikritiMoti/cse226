//
//  splashViewController.swift
//  eComplaint
//
//  Created by Student on 25/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit
import AVFoundation


class splashViewController: UIViewController {
    var player : AVAudioPlayer = AVAudioPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        do {
            let audioPath = Bundle.main.path(forResource: "startup", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!)as URL)
            
            } catch {
                print("Error playing sound: \(error.localizedDescription)")
            }
        
        player.play()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.performSegue(withIdentifier: "splash", sender: self)
        }

        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var logo: UIImageView!
    
    // Hide navigation bar when this view appears
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    // Show navigation bar again when transitioning to next view
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
