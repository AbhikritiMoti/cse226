//
//  homeViewController.swift
//  eComplaint
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

var pdata = String()

extension UIImageView {
    func roundBottomCorners(radius: CGFloat) {
        let maskPath = UIBezierPath(
            roundedRect: bounds,
            byRoundingCorners: [.bottomLeft, .bottomRight],
            cornerRadii: CGSize(width: radius, height: radius)
        )
        
        let maskLayer = CAShapeLayer()
        maskLayer.frame = bounds
        maskLayer.path = maskPath.cgPath
        
        layer.mask = maskLayer
    }
}
func setGradientBackground(colorOne: UIColor, colorTwo: UIColor, for view: UIView) {
    let gradientLayer = CAGradientLayer()
    gradientLayer.frame = view.bounds
    gradientLayer.colors = [colorOne.cgColor, colorTwo.cgColor]
    gradientLayer.locations = [0.0, 1.0]
    gradientLayer.startPoint = CGPoint(x: 1.0, y: 1.0)
    gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.0)
    
    view.layer.insertSublayer(gradientLayer, at: 0)
}






class homeViewController: UIViewController {



    override func viewDidLoad() {
        super.viewDidLoad()
        img2.layer.cornerRadius = 20
        img2.layer.masksToBounds = true
        
        cardimg1.layer.cornerRadius = 8
        cardimg1.layer.masksToBounds = true
        
        cardimg2.layer.cornerRadius = 8
        cardimg2.layer.masksToBounds = true
        
        cardimg3.layer.cornerRadius = 8
        cardimg3.layer.masksToBounds = true
        
        cardimg4.layer.cornerRadius = 8
        cardimg4.layer.masksToBounds = true

        img1.roundBottomCorners(radius: 35)
        
        img2.animationImages = eme
        img2.animationDuration = 2
        img2.animationRepeatCount = 0
        img2.startAnimating()
        
        name.text="\(pdata)"
        
        setGradientBackground(colorOne: .blue, colorTwo: .purple, for: img1)
        
    }
    
    var society : [UIImage] = [#imageLiteral(resourceName: "card1"),#imageLiteral(resourceName: "card2"),#imageLiteral(resourceName: "card3"),#imageLiteral(resourceName: "card4")]
    var university : [UIImage] = [#imageLiteral(resourceName: "cacademic"),#imageLiteral(resourceName: "chostels"),#imageLiteral(resourceName: "csport"),#imageLiteral(resourceName: "c")]
    
    
    @IBOutlet weak var ci1: UIImageView!
    
    @IBOutlet weak var segO: UISegmentedControl!
    
    @IBAction func segA(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 { // Check if the selected segment is "Society"
            cardimg1.image = society[0]
            cardimg2.image = society[1]
            cardimg3.image = society[2]
            cardimg4.image = society[3]
            cbtn1O.setTitle("        Roads", for: .normal)
            cbtn2O.setTitle("        Electricity", for: .normal)
            cbtn3O.setTitle("        Police", for: .normal)
            cbtn4O.setTitle("        Water", for: .normal)
            
            
            
        } else if sender.selectedSegmentIndex == 1 { // Check if the selected segment is "University"
            cardimg1.image = university[0]
            cardimg2.image = university[1]
            cardimg3.image = university[2]
            cardimg4.image = university[3]
            
            cbtn1O.setTitle("        Academic", for: .normal)
            cbtn2O.setTitle("        Hostel Facilities", for: .normal)
            cbtn3O.setTitle("        Sports", for: .normal)
            cbtn4O.setTitle("        Cultural", for: .normal)
        }
    
        
    }
    
    var eme : [UIImage] = [
        UIImage(named: "a")!,
        UIImage(named: "b")!,
        UIImage(named: "c")!
    ]
    
    @IBOutlet weak var dp: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet weak var name: UITextView!
    
    
    @IBOutlet weak var cardimg1: UIImageView!
    @IBOutlet weak var cardimg2: UIImageView!
    @IBOutlet weak var cardimg3: UIImageView!
    @IBOutlet weak var cardimg4: UIImageView!
    
    
    @IBOutlet weak var cbtn1O: UIButton!
    
    @IBOutlet weak var cbtn2O: UIButton!
    
    @IBOutlet weak var cbtn3O: UIButton!
    
    @IBOutlet weak var cbtn4O: UIButton!
    
    @IBAction func profileBtn(_ sender: Any) {
        performSegue(withIdentifier: "profile", sender: self)
    }
    
    
    @IBAction func cbtn1(_ sender: Any) {
        
        let sector = cbtn1O.title(for: .normal)
        
        if let sector = sector {
            pdata2 = sector
            performSegue(withIdentifier: "detail", sender: self)
        }
    }
    
    
    @IBAction func cbtn2(_ sender: Any) {
        let sector = cbtn2O.title(for: .normal)
        
        if let sector = sector {
            pdata2 = sector
            performSegue(withIdentifier: "detail", sender: self)
        }
    }
    

    
    @IBAction func cbtn3(_ sender: Any) {
        let sector = cbtn3O.title(for: .normal)
        
        if let sector = sector {
            pdata2 = sector
            performSegue(withIdentifier: "detail", sender: self)
        }
    }
    

    
    @IBAction func cbtn4(_ sender: Any) {
        let sector = cbtn4O.title(for: .normal)
        
        if let sector = sector {
            pdata2 = sector
            performSegue(withIdentifier: "detail", sender: self)
        }
    }
    
}
