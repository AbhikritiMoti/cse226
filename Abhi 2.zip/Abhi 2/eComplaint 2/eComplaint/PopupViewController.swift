//
//  PopupViewController.swift
//  eComplaint
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit
var selectedComplaint: Complaints?

class PopupViewController: UIViewController {

    @IBOutlet weak var namelabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    @IBOutlet weak var priorityLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var queryLabel: UILabel!
    
    @IBOutlet weak var quickLabel: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let complaint = selectedComplaint {
            // Display the complaint data in the labels
            namelabel.text = "Name: \(complaint.name)"
            ageLabel.text = "Age: \(String(complaint.age))"
            priorityLabel.text = "Priority: \(complaint.priority)"
            addressLabel.text = "Address: \(complaint.address)"
            idLabel.text = "ID: \(complaint.id)"
            queryLabel.text = "Query: \(complaint.query)"
            quickLabel.text = "Quick: \(complaint.isQuick ? "Yes" : "No")"
        }
    }
    
  

}
