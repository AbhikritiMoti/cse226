//
//  ToastView.swift
//  eComplaint
//
//  Created by Student on 30/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import Foundation
import UIKit

class ToastView: UIView {
    
    init(message: String) {
        super.init(frame: CGRect.zero)
        
        let label = UILabel()
        label.text = message
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        
        backgroundColor = UIColor(white: 0, alpha: 0.7)
        layer.cornerRadius = 10
        
        addSubview(label)
        
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            label.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8),
            ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

