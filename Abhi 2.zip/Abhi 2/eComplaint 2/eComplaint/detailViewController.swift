//
//  detailViewController.swift
//  eComplaint
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

var pdata2 = String()

class detailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        heading.text="\(pdata2) Complaint"
        
        submitO.layer.cornerRadius = 15

    
    }
    
    var complaints: [Complaints] = []

    
    
    @IBOutlet weak var heading: UILabel!
    
    @IBOutlet weak var eName: UITextField!
    @IBOutlet weak var eID: UITextField!
    
    @IBOutlet weak var eAdd: UITextField!
    
    @IBOutlet weak var eAge: UISlider!
    
    @IBOutlet weak var ePrior: UISegmentedControl!
    
    @IBOutlet weak var eQuery: UITextView!
    @IBOutlet weak var eQuick: UISwitch!
    
   
    
    @IBOutlet weak var submitO: UIButton!
    @IBAction func submit(_ sender: Any) {
        
        let name = eName.text ?? ""
        let id = eID.text ?? ""
        let address = eAdd.text ?? ""
        let age = Int(eAge.value)
        let priority = ePrior.titleForSegment(at: ePrior.selectedSegmentIndex) ?? ""
        let query = eQuery.text ?? ""
        let isQuick = eQuick.isOn
        
        let newComplaint = Complaints(name: name, id: id, address: address, age: age, priority: priority, query: query, isQuick: isQuick)
        
        
        complaints.append(newComplaint)
        print("copmpalint success")
        selectedComplaint = newComplaint
        performSegue(withIdentifier: "popup", sender: self)
        print("copmpalint success")

    }
}
