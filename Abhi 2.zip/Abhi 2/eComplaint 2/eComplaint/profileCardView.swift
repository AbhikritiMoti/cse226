
//
//  profileCardView.swift
//  eComplaint
//
//  Created by Student on 30/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable class profileCardView: UIView {
    var cornerRadius: CGFloat = 30
    var offsetWidth: CGFloat = 5
    var offsetHeight: CGFloat = 5
    var offsetShadow: Float = 8
    var color = UIColor.gray
    
    override func layoutSubviews() {
        // Create a mask path to round only the bottom left and bottom right corners
        let maskPath = UIBezierPath(
            roundedRect: bounds,
            byRoundingCorners: [.bottomLeft, .bottomRight],
            cornerRadii: CGSize(width: self.cornerRadius, height: self.cornerRadius)
        )
        
        // Set the layer's mask with the created path
        let maskLayer = CAShapeLayer()
        maskLayer.path = maskPath.cgPath
        layer.mask = maskLayer
        
        // Set the layer's shadow properties
        layer.shadowColor = self.color.cgColor
        layer.shadowOffset = CGSize(width: self.offsetWidth, height: self.offsetHeight)
        layer.shadowPath = maskPath.cgPath // Use the same path for shadow
        layer.shadowOpacity = self.offsetShadow
    }
}
