//
//  profileViewController.swift
//  eComplaint
//
//  Created by Student on 30/10/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit

class profileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        updateO.layer.cornerRadius = 15
        outO.layer.cornerRadius = 15
        newO.layer.cornerRadius = 15
        
    
        
        email.layer.borderWidth = 1.0
        email.layer.borderColor = UIColor.blue.cgColor
        pwd.layer.borderWidth = 1.0
        pwd.layer.borderColor = UIColor.blue.cgColor


        
        if let firstUser = UserManager.shared.users.first {
            name.text = firstUser.username
            email.text = firstUser.email
            pwd.text = firstUser.password
            
            switch firstUser.sex {
            case .male:
                ageSegment.selectedSegmentIndex = 0
            case .female:
                ageSegment.selectedSegmentIndex = 1
            case .other:
                ageSegment.selectedSegmentIndex = 2
            }
        } else {
            name.text = ""
            email.text = ""
            ageSegment.selectedSegmentIndex = UISegmentedControl.noSegment
        }
    }
    

    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var pwd: UITextField!
    
    @IBOutlet weak var ageSegment: UISegmentedControl!
    
    
    
    @IBOutlet weak var outO: UIButton!
    @IBAction func outA(_ sender: Any) {
        performSegue(withIdentifier: "out", sender: self)
    }
    
    @IBOutlet weak var newO: UIButton!
    @IBAction func newA(_ sender: Any) {
        performSegue(withIdentifier: "new", sender: self)
    }
    
    
    @IBOutlet weak var updateO: UIButton!
    
    @IBAction func updateA(_ sender: Any) {
        
        let selectedSegmentIndex = ageSegment.selectedSegmentIndex
        var updatedSex: Sex = .other
        
        switch selectedSegmentIndex {
        case 0:
            updatedSex = .male
        case 1:
            updatedSex = .female
        default:
            updatedSex = .other
        }
        
        if var user = UserManager.shared.users.first {
            user.username = name.text ?? ""
            user.email = email.text ?? ""
            user.password = pwd.text ?? ""
            user.sex = updatedSex
            UserManager.shared.users[0] = user
        }
        
        loadUserData()
        
        // toast
        showCustomToast(message: "User information updated!")
    }
    
    func loadUserData() {
        if let firstUser = UserManager.shared.users.first {
            name.text = firstUser.username
            email.text = firstUser.email
            pwd.text = firstUser.password
            
            switch firstUser.sex {
            case .male:
                ageSegment.selectedSegmentIndex = 0
            case .female:
                ageSegment.selectedSegmentIndex = 1
            default:
                ageSegment.selectedSegmentIndex = 2
            }
        } else {
            name.text = "No User Data Available"
            email.text = ""
            pwd.text = ""
            ageSegment.selectedSegmentIndex = UISegmentedControl.noSegment
        }
    }
    
    func showCustomToast(message: String) {
        let toastView = ToastView(message: message)
        toastView.alpha = 0
        view.addSubview(toastView)
        
        toastView.translatesAutoresizingMaskIntoConstraints = false
        toastView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        toastView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -50).isActive = true
        
        UIView.animate(withDuration: 0.3, animations: {
            self.view.layoutIfNeeded() // Update layout
            toastView.alpha = 1
        }) { (completed) in
            if completed {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    UIView.animate(withDuration: 0.3, animations: {
                        toastView.alpha = 0
                    }) { (completed) in
                        toastView.removeFromSuperview()
                    }
                }
            }
        }
    }

    

}
